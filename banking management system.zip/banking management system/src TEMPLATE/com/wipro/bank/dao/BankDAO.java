package com.wipro.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.util.DBUtil;

public class BankDAO {

	public boolean validateAccount(String accountNumber) {
		boolean validAccountStatus = false;

		//write code here
		return validAccountStatus;
	}

	public float findBalance(String accountNumber) {
		float balance = 0f;

	   //write code here
		return balance;
	}

	public boolean updateBalance(String accountNumber, float newBalance) {
		boolean status = false;
		//write code here
		return status;
	}

	public boolean transferMoney(TransferBean transferBean) {
		boolean transferStatus = false;
		//write code here
		return transferStatus;
	}

	public int generateSequenceNumber() {
		//write code here
		return -1;
	}

}
