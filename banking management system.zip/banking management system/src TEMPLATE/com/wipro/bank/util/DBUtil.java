package com.wipro.bank.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private static Connection connection = null;

	public static Connection getDBConnection() {
		//write code here
		return connection;
	}
}
