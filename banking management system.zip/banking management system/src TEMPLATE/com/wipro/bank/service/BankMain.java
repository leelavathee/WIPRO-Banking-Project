package com.wipro.bank.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.dao.BankDAO;
import com.wipro.bank.util.InsufficientFundsException;

public class BankMain {
	public static void main(String[] args) {
		//write code here
	}

	public String checkBalance(String accountNumber) {
		
		//write code here
		return "";
	}

	public String transfer(TransferBean transferBean) {
		String status = "";
	    //write code here
		return status;
	}
}
