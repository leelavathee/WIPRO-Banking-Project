package com.wipro.bank.service;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.dao.BankDAO;
import com.wipro.bank.util.InsufficientFundsException;

public class BankMain {
	public static void main(String[] args) {
		//write code here
	}

	public String checkBalance(String accountNumber) {
		
		//write code here
		BankDAO a=new BankDAO();
		if(!a.validateAccount(accountNumber)){
			return "ACCOUNT NUMBER INVALID";
		}
		float f=a.findBalance(accountNumber);
		return "BALANCE IS:"+f;
	}

	public String transfer(TransferBean transferBean) {
		String status = "";
	    
		if(transferBean==null) {
			return "INVALID";
		}
		BankDAO a=new BankDAO();
		if((a.validateAccount(transferBean.getFromAccountNumber())==false ) ||( a.validateAccount(transferBean.getToAccountNumber())==false)) {
			return "INVALID ACCOUNT";
		}
		float money=a.findBalance(transferBean.getFromAccountNumber());
		if(money==0 || money<transferBean.getAmount()) {
			try {throw new InsufficientFundsException();}catch( InsufficientFundsException e) {
				return "INSUFFICIENT FUNDS";
				
			}
			
		
		}
		a.updateBalance(transferBean.getFromAccountNumber(), a.findBalance(transferBean.getFromAccountNumber())-transferBean.getAmount());
		a.updateBalance(transferBean.getToAccountNumber(), a.findBalance(transferBean.getToAccountNumber())+transferBean.getAmount());
		a.transferMoney(transferBean);
		status="SUCCESS";
		
		return status;
	}
}
