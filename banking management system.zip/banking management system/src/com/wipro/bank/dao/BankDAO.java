package com.wipro.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.util.DBUtil;

public class BankDAO {

	public boolean validateAccount(String accountNumber) {
		boolean validAccountStatus = false;
		Connection con=DBUtil.getDBConnection();
		try {
			Statement s=con.createStatement();
			ResultSet r=s.executeQuery("select * from ACCOUNT_TBL");
			boolean flag =false;
			while(r.next()) {
				 if(r.getString(1).equals(accountNumber)) {
					    flag=true;
					    break;
				 }
			}
			if(flag) {
				validAccountStatus=true;
			}else {
				validAccountStatus=false;
			}
		
			
		} catch (SQLException e) {
			    e.printStackTrace();
		}
		


		return validAccountStatus;
	}

	public float findBalance(String accountNumber) {
		float balance = 0f;

	   //write code here
		boolean validAccountStatus = validateAccount( accountNumber);  
		if(validAccountStatus) {
			Connection con=DBUtil.getDBConnection();
			PreparedStatement p;
			try {
				p = con.prepareStatement("select Balance from ACCOUNT_TBL where Account_Number=?");
				p.setString(1, accountNumber);
				ResultSet r=p.executeQuery();
				while(r.next()) {
					balance=r.getFloat(1);
				}
				
			} catch (SQLException e) {
				   e.printStackTrace();
			}
			
			
			
		}else {
			  balance =-1f;
			    
		}
		
		return balance;
	}

	public boolean updateBalance(String accountNumber, float newBalance) {
		boolean status = false;
		boolean f=validateAccount(accountNumber);
		if(f) {
			
			Connection con=DBUtil.getDBConnection();
			try {
				PreparedStatement p = con.prepareStatement("update  ACCOUNT_TBL set Balance= ? where Account_Number=?");
				p.setFloat(1, newBalance);
				p.setString(2, accountNumber);
			    boolean r=p.execute();
			    if(!r) {
			    	status = true;
			    }else {
			    	status=false;
			    }
				
			} catch (SQLException e) {
				status = false;
			}
		}
	
		
		return status;
	}

	public boolean transferMoney(TransferBean transferBean) {
		boolean transferStatus = false;
		//write code here
		
	    try {
	    	Connection con=DBUtil.getDBConnection();
			PreparedStatement  p = con.prepareStatement("insert into TRANSFER_TBL values(?,?,?,?,?)");
			p.setInt(1, generateSequenceNumber() );
			p.setString(2,transferBean.getFromAccountNumber());
			p.setString(3, transferBean.getToAccountNumber());
			p.setDate(4, new Date(transferBean.getDateOfTransaction().getTime()));
			p.setFloat(5, transferBean.getAmount());
			boolean f=p.execute();
			if(!f) {
				transferStatus = true;
				
			}
			else {
				transferStatus = false;
			}
			
		} catch (Exception e) {
			    System.out.println("Date problem");
		}
	
		
		
		return transferStatus;
	}

	public int generateSequenceNumber() {
		Connection con=DBUtil.getDBConnection();
		try {
			Statement s=con.createStatement();
			ResultSet r=s.executeQuery("select transactionId_seq.nextval from dual");
			while(r.next()) {
				return r.getInt(1);
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return -1;
	}

}
