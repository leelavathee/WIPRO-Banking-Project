package com.wipro.bank.util;

public class InsufficientFundsException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString() {
	
		return "INSUFFICIENT FUNDS";
	}
}
 